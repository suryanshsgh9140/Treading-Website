package com.zosh.domain;

public enum OrderType {
    BUY,
    SELL
}
