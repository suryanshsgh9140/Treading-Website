package com.zosh.domain;

public enum USER_ROLE {
    ROLE_ADMIN, ROLE_USER
}
